/rocket-tech
|-- index.html (Home Page)
|-- media.html (Media Page)
|-- contact.html (Contact Page)
|-- style.css (Shared CSS)
|-- script.js (JavaScript for animations)
